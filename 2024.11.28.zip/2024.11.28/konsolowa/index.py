#************************************************ 
#  klasa:   <String_mod> 
#  opis:    <klasa posiada dwie metody, wykonujące operacje na stringach, jest to, zliczanie samogłosek oraz usuwające duplikaty z tekstu podanego przez urzytkjownika> 
#  metody:  <counter - zmienną typu int, o wartośći równej ilości samogłosek w podanym przez urzytkownika tekście> 
#           <delete_duplicate - zmienną typu string, zawierającą tekst podany przez urzytkownika odpowiednio przerobiona przez program> 
#  autor:   <NIe mam numeru bo nie byłem na obozie> 
#************************************************

class String_mod:
    @staticmethod
    def counter(string):
        samogloski = "aąeęiouóyAĄEĘIOUÓY"
        count = 0

        if(string != "" or string.isalpha):
            for s in string:
                for x in samogloski:
                    if s == x:
                        count += 1

        return count
    
    @staticmethod
    def delete_duplicate(string):
        string2 = ""
        i = 0

        while i < len(string):
            if i == 0:
                string2 += string[i]
            elif(string[i] != string[i-1]):
                string2 += string[i]

            i += 1

        return(string2)

#----------------------------------------------------------------

podana_wartosc = input("Podaj ciąg znaków do przeszukania: ")
print(f"Liczba samogłosek w łańcuchu: {String_mod.counter(podana_wartosc)}")
print(f"Łańcuch bez powtóżonych po sobie znakaów: {String_mod.delete_duplicate(podana_wartosc)}")

