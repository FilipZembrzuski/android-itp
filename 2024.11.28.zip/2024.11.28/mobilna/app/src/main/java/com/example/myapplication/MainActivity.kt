package com.example.myapplication

import android.R
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    fun changeAge(age: Int, textBox: TextView) {
        textBox.text = ("Ile ma lat: " + age.toString())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val listitems = mutableListOf("Pies", "Kot", "Świnka morska")

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, listitems)
        binding.lista.adapter = adapter

        binding.AgeSlider.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val textBox = binding.ageText
                changeAge(progress, textBox)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }
        })

        var zwierz = ""

        binding.lista.setOnItemClickListener { parent, view, position, id ->
            when (position) {
                0 -> {
                    binding.AgeSlider.max = 18
                    zwierz = "Pies"
                }
                1 -> {
                    binding.AgeSlider.max = 20
                    zwierz = "Kot"
                }
                2 -> {
                    binding.AgeSlider.max = 9
                    zwierz = "Świnka morska"
                }
            }
        }


        binding.accept.setOnClickListener(){
            val nameText = binding.clientName.text.toString()
            val celText = binding.VisitTarget.text.toString()
            val godzinaText = binding.Hour.text.toString()
            val seekBarValue = binding.AgeSlider.progress

            binding.wynik.text = "$nameText, $zwierz $seekBarValue, $celText, $godzinaText"
        }
    }
}